# Historique des versions

## [v1.0.49] - Final Documentation
- **Doc :** Ajout des instructions d'installation Python/FFmpeg dans le Readme.

## [v1.0.44] - Stable Release
- **Core :** Moteur audio stabilisé (Fix Bruit blanc & Synchro).
- **UI :** Interface Glassmorphism complète avec lecteur Waveform.
- **Features :** Modes 6s/4s/2s, Analyse BPM, Monitoring CPU, Raccourcis Clavier.
