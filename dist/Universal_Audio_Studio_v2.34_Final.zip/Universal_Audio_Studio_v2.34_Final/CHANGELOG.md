# Changelog
## [v2.34] - Final Fix
- Correction du script de génération de release.

## [v2.33] - Bit Depth
- Ajout de l'analyse 16/24/32-bit.
- Correction nommage De-Reverb.
